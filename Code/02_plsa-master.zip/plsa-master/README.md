A python implementation of plsa (probabilistic latent semantic analysis).
The input is docs with a dicts list which like [{word0: count_word0, word1: count_word1}, {word0: count_word0}].
It provides train and inference function.
